package utility;

public class ExceptionHandler extends Exception {

	public ExceptionHandler(String msg) {
		super(msg);
	}
}
